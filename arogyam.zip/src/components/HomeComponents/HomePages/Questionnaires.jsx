import { useNavigate } from "react-router-dom";

function Questionnaires(){
    const navigate = useNavigate();
    return(
        <h1>Questionnaires</h1>
    )
}

export default Questionnaires;