
function Ventout(){

    return(
        <h1>vent out</h1>
    )
}

export default Ventout;