import NavbarBeforeLogin from "../components/NavbarBeforeLogin";

function Landing(){
    return(
        <>
        <NavbarBeforeLogin />
        </>
    )
}

export default Landing;